# Adi Account Gen

An Adidas account generator supports all countries, with captcha bypass.

# How to use
Must have Python 3 installed
Run installer.bat
Edit config.json
Done
Example domains (USA = US, UK = co.uk, Canada = CA)
I'm more than happy to provide help on Discord